import sqlite3 from 'sqlite3';
import {open} from 'sqlite';

export const initDB = async () => {
  const db=await open({
    filename:'./db/database.sqlite',
    driver:sqlite3.Database,
  });

  await db.exec(`
    CREATE TABLE IF NOT EXISTS employees (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT,
      email TEXT,
      position TEXT,
      status TEXT DEFAULT 'active'
    )
  `);

  return db;
};
