import {Router} from 'express';
import {initDB} from '../app';

const router = Router();
//Add employee
router.post('/',async (req,res) => {
  const db=await initDB();
  const {name,email,position}=req.body;
  await db.run(
    'INSERT INTO employees (name, email, position) VALUES (?, ?, ?)',
    [name,email,position]
  );
  res.status(201).send({message:'Employee added successfully' });
});


router.get('/', async (req,res) => {
  const db=await initDB();
  const employees=await db.all('SELECT * FROM employees WHERE status = "active"');
  res.status(200).json(employees);
});

//employee
router.get('/:id', async (req,res)=> {
  const db=await initDB();
  const employee=await db.get('SELECT * FROM employees WHERE id = ?',[req.params.id]);
  res.status(200).json(employee);
});

//Update
router.put('/:id',async (req,res)=> {
  const db=await initDB();
  const {name,email,position}=req.body;
  await db.run(
    'UPDATE employees SET name = ?, email = ?,position = ? WHERE id = ?',
    [name,email,position,req.params.id]
  );
  res.status(200).send({message:'Employee updated successfully'});
});

//delete
router.delete('/:id', async (req, res) => {
  const db=await initDB();
  await db.run('UPDATE employees SET status = "inactive" WHERE id = ?',[req.params.id]);
  res.status(200).send({ message:'Employee soft deleted successfully'});
});

export default router;
