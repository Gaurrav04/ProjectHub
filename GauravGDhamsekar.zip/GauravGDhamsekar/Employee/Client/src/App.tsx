import React,{useState} from 'react';
import EmployeeForm from './components/EmployeeForm';
import EmployeeList from './components/EmployeeList';
import EmployeeDetails from './components/EmployeeDetails';
import './App.css';

const App: React.FC=()=> 
  {
  const[selectedEmployeeId,setSelectedEmployeeId]=useState<number |null>(null);
  const[viewEmployeeId,setViewEmployeeId] =useState<number |null>(null);
  const[refresh,setRefresh]=useState(false);

  const handleEmployeeSaved =()=>{
    setRefresh(!refresh);
    setSelectedEmployeeId(null);
  };

  const handleEdit=(employeeId:number)=>{
    setSelectedEmployeeId(employeeId);
    setViewEmployeeId(null);
  };

  const handleView=(employeeId:number)=>{
    setViewEmployeeId(employeeId);
    setSelectedEmployeeId(null);
  };

  const handleBack=()=>{
    setViewEmployeeId(null);
  };

  return (
    <div>
      <h1>Employee Management</h1>
      {!viewEmployeeId && (
        <div>
          <EmployeeForm employeeId={selectedEmployeeId || undefined}onEmployeeSaved={handleEmployeeSaved} />
          <EmployeeList onEdit={handleEdit} onRefresh={()=>setRefresh(!refresh)} />
        </div>
      )}
      {viewEmployeeId && <EmployeeDetails employeeId={viewEmployeeId} onBack={handleBack}/>}
    </div>
  );
};

export default App;
