import React, { useEffect, useState } from 'react';
import api from '../api';

interface Employee {
  id:number;
  name:string;
  email:string;
  position:string;
  status:string;
}

interface EmployeeListProps {
  onEdit:(employeeId:number)=> void;
  onRefresh:()=>void;
}

const EmployeeList:React.FC<EmployeeListProps>=({onEdit,onRefresh }) => {
  const [employees,setEmployees]=useState<Employee[]>([]);

  useEffect(()=> {
    fetchEmployees();
  }, [onRefresh]);

  const fetchEmployees =async()=> {
    const response=await api.get('/employees');
    setEmployees(response.data);
  };

  const handleDelete=async (employeeId:number) => {
    await api.delete(`/employees/${employeeId}`);
    fetchEmployees();
  };

  return (
    <div>
      <h2>Employee List</h2>
      <ul>
        {employees.map((employee)=> (
          <li key={employee.id}>
            <strong>{employee.name}</strong> -{employee.position}
            <button onClick={()=>onEdit(employee.id)}>Edit</button>
            <button onClick={()=>handleDelete(employee.id)}>Delete</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default EmployeeList;
