
import React, {useState,useEffect } from 'react';
import api from '../api';

interface EmployeeFormProps {
  employeeId?:number;
  onEmployeeSaved:()=> void;
}

const EmployeeForm: React.FC<EmployeeFormProps>=({employeeId,onEmployeeSaved })=> {
  const [name,setName]=useState('');
  const [email,setEmail]=useState('');
  const [position,setPosition]=useState('');

  //editing
  useEffect(()=> {
    if (employeeId) {
      api.get(`/employees/${employeeId}`).then((response) => {
        const { name,email,position}=response.data;
        setName(name);
        setEmail(email);
        setPosition(position);
      });
    }
  }, [employeeId]);

  // add
  const handleSubmit=async (e:React.FormEvent)=> {
    e.preventDefault();

    const employeeData={name,email,position };

    if (employeeId) {
      //update 
      await api.put(`/employees/${employeeId}`,employeeData);
    } else {
      //add
      await api.post('/employees',employeeData);
    }

    onEmployeeSaved(); 
    setName('');
    setEmail('');
    setPosition('');
  };

  return (
    <form onSubmit={handleSubmit}>
      <h3>{employeeId ?'Edit Employee':'Add Employee'}</h3>
      <input
        type="text"
        placeholder="Name"
        value={name}
        onChange={(e)=> setName(e.target.value)}
        required
      />
      <input
        type="email"
        placeholder="Email"
        value={email}
        onChange={(e) =>setEmail(e.target.value)}
        required
      />
      <input
        type="text"
        placeholder="Position"
        value={position}
        onChange={(e)=>setPosition(e.target.value)}
        required
      />
      <button type="submit">{employeeId ? 'Update':'Add'} Employee</button>
    </form>
  );
};

export default EmployeeForm;
