import React, { useEffect, useState } from 'react';
import api from '../api';

interface EmployeeDetailsProps {
  employeeId:number;
  onBack:()=>void;
}

const EmployeeDetails:React.FC<EmployeeDetailsProps> =({employeeId,onBack}) => {
  const [employee,setEmployee]=useState<any>(null);

  useEffect(() => {
    api.get(`/employees/${employeeId}`).then((response) => {
      setEmployee(response.data);
    });
  }, [employeeId]);

  if (!employee) {
    return <div>Loading.</div>;
  }

  return (
    <div>
      <h2>Employee Details</h2>
      <p><strong>Name:</strong>{employee.name}</p>
      <p><strong>Email:</strong>{employee.email}</p>
      <p><strong>Position:</strong>{employee.position}</p>
      <p><strong>Status:</strong>{employee.status}</p>
      <button onClick={onBack}>Back to List</button>
    </div>
  );
};

export default EmployeeDetails;
