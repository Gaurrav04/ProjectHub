import json
import time
import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

#Credentials
def load():
    try:
        with open('data/credentials.json')as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading credentials:{e}")
        raise

#Save
def save(products):
    try:
        with open('data/products.json','w')as f:
            json.dump(products,f,indent=4)
        print("Products saved successfully")
    except Exception as e:
        print(f"Error saving products:{e}")
        raise

def update(driver,products):
    try:
        if len(products)>=3:
            products['Product 3']['price'] = "$100"
            save(products)
            print("Product 3 price updated to $100")

            Product="Sauce Labs Bolt T-Shirt"
            Ppath=f"//div[contains(text(),'{Product}')]//ancestor::div[contains(@class,'inventory_item')]//div[contains(@class,'inventory_item_price')]"
            time.sleep(5)
        else:
            print("Not enough products to update.")
    except Exception as e:
        print(f"Error updating product price:{e}")
        raise

#Fetch
def FetchData():
    try:
        response=requests.get('https://jsonplaceholder.typicode.com/posts')
        response.raise_for_status()
        api_data = response.json()
        with open('data/api_response.json', 'w') as f:
            json.dump(api_data[0], f, indent=4)
        print("API data fetched and saved successfully.")
    except Exception as e:
        print(f"Error fetching API data:{e}")
        raise

#Main
credentials=load()

OpenChrome=Options()
OpenChrome.add_argument("--start-maximized")
service=Service('/usr/local/bin/chromedriver')
driver=webdriver.Chrome(service=service, options=OpenChrome)

try:
    print("Logging in..")
    driver.get("https://www.saucedemo.com/")
    time.sleep(2)
    driver.find_element(By.ID,"user-name").send_keys(credentials['username'])
    time.sleep(1)
    driver.find_element(By.ID,"password").send_keys(credentials['password'])
    time.sleep(1)
    driver.find_element(By.ID,"login-button").click()
    time.sleep(3)
    print("Login successful")

    products = {}
    print("Fetching product details.")
    time.sleep(2)
    ProductsE=driver.find_elements(By.CLASS_NAME,"inventory_item")
    
    for index,product in enumerate(ProductsE):
        title=product.find_element(By.CLASS_NAME,"inventory_item_name").text
        description=product.find_element(By.CLASS_NAME,"inventory_item_desc").text

        price=product.find_element(By.CLASS_NAME,"inventory_item_price").text
        products[f'Product {index+1}']={"description":description,"price": price}
        print(f"Fetched{title}:{description},Price:{price}")
        time.sleep(1)

    save(products)

    update(driver,products)
    FetchData()

    assert len(products)>0,"No products found"
    assert products['Product 3']['price']=="$100","Product 3 price not updated correctly"

except Exception as e:
    print(f"Error: {e}")
finally:
    driver.quit()
    print("Driver closed")
